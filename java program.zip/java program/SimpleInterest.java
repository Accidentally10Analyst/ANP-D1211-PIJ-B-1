public class SimpleInterest {
    public static void main(String[] args) {
        double P = 1000, R = 5, T = 2;
        double SI = (P * R * T) / 100;
        System.out.println("Simple Interest is: " + SI);
    }
}
