class Animal {
    String name;
    int cost;

    // Constructor
    public Animal(String name, int cost) {
        this.name = name;
        this.cost = cost;
    }

    // Method to print the details
    public void printP() {
        System.out.println("Name: " + name);
        System.out.println("Cost: " + cost);
    }
}

public class Demof {
    public static void main(String[] args) {
        // Create an Animal object
        Animal a = new Animal("minal", 12000);

        // Call the method to print details
        a.printP();
    }
}
