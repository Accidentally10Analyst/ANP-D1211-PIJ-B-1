public class EvenOdd {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 5) {
            System.out.println(i + " is " + (i % 2 == 0 ? "Even" : "Odd"));
            i++; // for increment i used
        }
    }
}
