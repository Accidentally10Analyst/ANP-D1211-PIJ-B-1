public class QuotientRemainder {
    public static void main(String[] args) {
        int dividend = 25, divisor = 4;
        System.out.println("Quotient: " + (dividend / divisor));
        System.out.println("Remainder: " + (dividend % divisor));
    }
}
