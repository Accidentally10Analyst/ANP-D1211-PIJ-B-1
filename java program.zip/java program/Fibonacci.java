public class Fibonacci {
    public static void main(String[] args) {
        int a = 0, b = 1, i = 1;
        while (i++ <= 10) {
            System.out.print(a + " ");
            b = b + (a = b - a);
        }
    }
}
