public class FactorialWhile {
    public static void main(String[] args) {
        int num = 5, i = 1, fact = 1;

        while (i <= num) {
            fact *= i;
            i++; // increment
        }

        System.out.println("Factorial of " + num + " is: " + fact);
    }
}
