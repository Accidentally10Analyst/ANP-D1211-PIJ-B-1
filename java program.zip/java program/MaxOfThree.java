public class MaxOfThree {
    public static void main(String[] args) {
        int a = 10, b = 20, c = 15;

        // Ternary operator checks conditions in short form
        int max = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);

        System.out.println("Max is: " + max);
    }
}
