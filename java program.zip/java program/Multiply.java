public class Multiply {
    public static void main(String[] args) {
        int a = 5, b = 6;
        System.out.println("Product is: " + (a * b));
    }
}
