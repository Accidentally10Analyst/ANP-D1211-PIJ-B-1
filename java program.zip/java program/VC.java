public class VC {
    public static void main(String[] args) {
        char ch = 'a';
        ch = Character.toLowerCase(ch); // handle uppercase

        boolean isVowel = (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u');

        System.out.println(ch + " is " + (isVowel ? "a Vowel" : "a Consonant"));
    }
}
