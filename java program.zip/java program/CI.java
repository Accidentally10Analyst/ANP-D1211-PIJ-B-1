public class CI {
    public static void main(String[] args) {
        double P = 1000, R = 5, T = 2;
        double A = P * Math.pow(1 + R / 100, T);
        double CI = A - P;

        System.out.println("Compound Interest is: " + CI);
    }
}
