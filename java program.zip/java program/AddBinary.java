public class AddBinary {
    public static void main(String[] args) {
        String a = "1010"; // binary as string
        String b = "1101";

        int num1 = Integer.parseInt(a, 2); // convert binary string to decimal int
        int num2 = Integer.parseInt(b, 2);
        int sum = num1 + num2; // add decimal numbers

        String binarySum = Integer.toBinaryString(sum); // convert sum back to binary string
        System.out.println("Sum: " + binarySum);
    }
}
